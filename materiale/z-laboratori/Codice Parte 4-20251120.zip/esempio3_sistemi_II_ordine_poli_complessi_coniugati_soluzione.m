%
% Sistema del secondo ordine - coefficiente di smorzamento (xi)
%
close all; clear all; clc;

% parametri del sistema
omegan = 15;

s = tf('s');
time = 0:0.01:2; % intervallo temporale

figure;
hold on; box on; zoom on; grid on;

% ciclo su valori di xi da 0.1 a 0.9
for xi=0.1:0.1:0.9

    % definizione del sistema
    G = omegan^2/(s^2 + 2*xi*omegan*s + omegan^2);

    % risposta al gradino
    YY = step(G, time);

    % plot
    plot(time, YY, 'DisplayName', ['\xi = ' num2str(xi)], 'LineWidth', 1.3);
end

legend;


figure;
hold on; box on; zoom on; grid on;

xi = 0.15;

% ciclo su valori di omega_n da 1 a 1000
for omegan=[10 50 100]

    % definizione del sistema
    G = omegan^2/(s^2 + 2*xi*omegan*s + omegan^2);

    % risposta al gradino
    YY = step(G, time);

    % plot
    plot(time, YY, 'DisplayName', ['\omega_n = ' num2str(omegan)], 'LineWidth', 1.3);
end

legend;