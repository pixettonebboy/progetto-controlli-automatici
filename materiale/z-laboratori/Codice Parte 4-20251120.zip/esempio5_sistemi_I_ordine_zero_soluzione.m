%
% Sistema del primo ordine - zero
%
close all; clear all; clc;

time = 0:0.01:5; % intervallo temporale

figure;
hold on; box on; zoom on; grid on;

s = tf('s');

T = 1;

% ciclo su valori di T da 0.1 a 1
for alpha=-0.2:0.3:1.6

    
    %%%%%%%%%%%%%%%%%%%%%
    %%% - dichiarazione FdT
    G = (1 + alpha*T*s)/(1 + s*T);
    %%% - calcolo risposta a gradino in YY
    YY = step(G,time);
    %%%%%%%%%%%%%%%%%%%%%

    % plot
    plot(time, YY, 'DisplayName', ['\alpha = ' num2str(alpha)], 'LineWidth', 1.3);
end

legend;