%
% FdT Carrello
%
close all; clear all; clc;

% parametri fisici del sistema
mass = 0.5; % kg
elas = 1;   % costante elastica [N/m]

%% creazione oggetto sistema e soluzione equazione differenziale

% matrici del sistema
A = [0 1; -elas/mass 0];
B = [0; 1/mass];
C = [1 0];
D = 0;

% intervallo di tempo
TT = 0:0.1:10; % da 0 a 10 secondi con passo 0.1

%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare FdT %%%
modello = ss(A,B,C,D);
G = tf(modello);
%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare poli e zeri %%%
p = pole(G)

z = zero(G)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Mostrare poli sul piano complesso %%%
pzmap(G);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Mostrare risposta a gradino %%%
figure

step(G,TT)

hold on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Mostrare risposta a gradino usando il modello nello spazio degli stati %%%
[YY, tt, XX] = lsim(modello,ones(length(TT),1),TT,randn(2,1))

plot(TT,YY,'Color','r')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

