%
% Sistema del primo ordine - costante di tempo T
%
close all; clear all; clc;

s = tf('s');
time = 0:0.01:5; % intervallo temporale

figure;
hold on; box on; zoom on; grid on;

% ciclo su valori di T da 0.1 a 1
for T=0.1:0.1:1

    % definizione del sistema
    G = 1/(1 + s*T);

    % risposta al gradino
    YY = step(G, time);

    % plot
    plot(time, YY, 'DisplayName', ['T = ' num2str(T)], 'LineWidth', 1.3);
end

legend;