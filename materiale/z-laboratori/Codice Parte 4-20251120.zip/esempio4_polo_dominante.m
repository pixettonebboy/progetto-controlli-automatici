clear all; close all; clc;


%%%%%%%%%%%%%%%%%%%%%%
%%% Definire G1(s) %%%
%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%
%%% Definire G1(s) %%%
%%%%%%%%%%%%%%%%%%%%%%

time = 0:0.1:10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare la risposta Y1 di G1 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare la risposta Y2 di G2 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure

plot(time,Y1,'LineWidth',2);
hold on;
plot(time,Y2,'LineWidth',2);

legend('$y_1(t)$','$y_2(t)$','Interpreter','latex');