clear all; close all; clc;


s = tf('s');

T1 = 1;
T2 = 1e-1;

G1 = 1/((1+T1*s)*(1+ T2*s));
G2 = 1/(1+T1*s);

time = 0:0.1:10;

Y1 = step(G1,time);
Y2 = step(G2,time);

figure

plot(time,Y1,'LineWidth',2);
hold on;
plot(time,Y2,'LineWidth',2);

legend('$y_1(t)$','$y_2(t)$','Interpreter','latex');