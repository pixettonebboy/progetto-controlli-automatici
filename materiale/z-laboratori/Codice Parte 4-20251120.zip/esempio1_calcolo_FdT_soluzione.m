%
% FdT Carrello
%
close all; clear all; clc;

% parametri fisici del sistema
mass = 0.5; % kg
elas = 1;   % costante elastica [N/m]

%% creazione oggetto sistema e soluzione equazione differenziale

% matrici del sistema
A = [0 1; -elas/mass 0];
B = [0; 1/mass];
C = [1 0];
D = 0;

% calcolo FdT: due alternative. Scegliere tramite if
if 0
    s = tf('s');
    G = C*inv(s*eye(2) - A)*B + D;
else
    modello = ss(A,B,C,D);
    G = tf(modello);
end

% elenco dei poli
pp = pole(G);
fprintf('Poli del sistema:\n');
disp(pp);

% elenco degli zeri
zz = zero(G);
fprintf('Zeri del sistema:\n');
disp(zz);


% diagramma poli/zeri
figure;
pzmap(G);

% intervallo di tempo
TT = 0:0.1:10; % da 0 a 10 secondi con passo 0.1

% risposta al gradino
figure;

step(G,TT);

hold on;

[YY,tt] = lsim(modello,ones(size(TT)),TT,[0;0]);

plot(tt,YY,'color','r');

legend('Risposta con simulazione FdT','Risposta con simulazione nello spazio degli stati')