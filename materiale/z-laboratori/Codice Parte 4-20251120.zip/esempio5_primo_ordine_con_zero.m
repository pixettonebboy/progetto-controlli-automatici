clear all; close all; clc;

TT = 0:0.01:15; % intervallo temporale

figure;
hold on; box on; zoom on; grid on;

% ciclo su valori di tau
for alpha=[0,1,4,7]
    
    %%%%%%%%%%%%%%%%%%%%%%
    %%% Dichiarare FdT %%%
    %%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Calcolare risposta a gradino in YY %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % plot
    plot(TT, YY,'DisplayName', ['\alpha = ' num2str(alpha)], 'LineWidth', 1.3);
end
legend;