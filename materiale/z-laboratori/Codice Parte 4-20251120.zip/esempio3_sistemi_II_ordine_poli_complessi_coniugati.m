%
% Sistema del secondo ordine - coefficiente di smorzamento (xi)
%
close all; clear all; clc;

% parametri del sistema
omegan = 15;

time = 0:0.01:2; % intervallo temporale

figure;
hold on; box on; zoom on; grid on;

% ciclo su valori di xi da 0.1 a 0.9
for xi=0.1:0.1:0.9

    %%%%%%%%%%%%%%%%%%%%%%
    %%% Dichiarare FdT %%%
    %%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Calcolare risposta a gradino in YY %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % plot
    plot(time, YY, 'DisplayName', ['\xi = ' num2str(xi)], 'LineWidth', 1.3);
end

legend;



figure;
hold on; box on; zoom on; grid on;

% ciclo su valori di omegan da 10 a 100
for omegan=[10 50 100]

    %%%%%%%%%%%%%%%%%%%%%%
    %%% Dichiarare FdT %%%
    %%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Calcolare risposta a gradino in YY %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % plot
    plot(time, YY, 'DisplayName', ['\omega_n = ' num2str(omegan)], 'LineWidth', 1.3);
end

legend;