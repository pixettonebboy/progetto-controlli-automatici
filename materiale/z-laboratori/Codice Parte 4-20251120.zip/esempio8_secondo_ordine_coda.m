clear all; close all; clc;


TT = 0:0.01:25; % intervallo temporale

figure;
hold on; box on; zoom on; grid on;

s = tf('s');

% ciclo su valori di tau
%for tau=
    
    %%%%%%%%%%%%%%%%%%%%%%
    %%% Dichiarare FdT %%%
    %%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Calcolare risposta a gradino in YY %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % plot
    plot(TT, YY, 'LineWidth', 1.3);
end
legend('\tau < T_1','\tau = T_1','\tau > T_1');