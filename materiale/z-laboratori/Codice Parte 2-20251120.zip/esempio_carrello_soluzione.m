%
% Esempio Carrello con Control System Toolbox
%
close all; clear all; clc;

% parametri fisici del sistema
mass = 0.5; % kg
k    = 1;   % costante elastica [N/m]

%%% Generazione oggetto sistema carrello
A = [0 1;-k/mass 0];

B = [0; 1/mass];

C = [1 0];

D = 0;

modello = ss(A,B,C,D);

% conditizioni inizali
x_0 = [0; 1];


% intervallo di tempo
interv = 0:0.1:10; % da 0 a 10 secondi con passo 0.1

T = 5; 

uu = sin(2*pi*interv/T);

% evoluzione libera
[YY_free, TT_free, XX_free] = lsim(modello,zeros(size(uu)),interv,x_0);

% evoluzione forzata
[YY_forced, TT_forced, XX_forced] = lsim(modello,uu,interv,zeros(2,1));

% evoluzione "completa"
[YY, TT, XX] = lsim(modello, uu, interv, x_0);

%%% Grafici

figure;
plot(TT_free,XX_free)

% Evoluzione libera
title('Traiettoria di stato del carrello (evoluzione libera)')

xlabel('tempo [s]')
ylabel('stato')
legend('posizione', 'velocità')
grid on; zoom on; box on;

% Evoluzione forzata
figure;
plot(TT_forced,XX_forced)
title('Traiettoria di stato del carrello (evoluzione forzata)')

xlabel('tempo [s]')
ylabel('stato')
legend('posizione', 'velocità')
grid on; zoom on; box on;

% Evoluzione completa
figure;
plot(TT, XX)
title('Traiettoria di stato del carrello (evoluzione completa)')

xlabel('tempo [s]')
ylabel('stato')
grid on; zoom on; box on;

hold on;

plot(TT,XX_free + XX_forced)


xlabel('tempo [s]')
ylabel('stato')
legend('posizione "completa"', 'velocità "completa"','posizione libera + forzata', 'velocità libera + forzata')
grid on; zoom on; box on;
