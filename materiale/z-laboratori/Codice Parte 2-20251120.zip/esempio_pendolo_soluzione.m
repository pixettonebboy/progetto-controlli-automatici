close all; clear all; clc;

% parametri fisici del sistema
mass = 0.5;   % kg
length = 0.6; % metri
grav = 9.81;  % m/s^2
attr = 0.25;  % coefficiente d'attrito (b)

% condizione iniziale del pendolo
theta_0 = deg2rad(30);
theta_punto_0 = 0;

x_0 =[theta_0;theta_punto_0];

% input
inp_free = @(t) 0;
inp_forced = @(t) 2;

% intervallo di tempo
interv = 0:0.1:10; % da 0 a 10 secondi


f_tilde_free = @(t,x) [x(2);-grav/length*sin(x(1)) - attr*x(2)/(mass*length^2) + inp_free(t)/(mass*length^2)];
f_tilde_forced = @(t,x) [x(2);-grav/length*sin(x(1)) - attr*x(2)/(mass*length^2) + inp_forced(t)/(mass*length^2)];


% evoluzione libera
[time_free,traj_free] = ode45(f_tilde_free,interv,x_0);

% evoluzione forzata
[time_forced,traj_forced] = ode45(f_tilde_forced,interv,zeros(2,1));

% evoluzione "completa"
[time,traj] = ode45(f_tilde_forced,interv,x_0);


%%% Grafici

% evoluzione libera
figure
plot(time_free,traj_free)
title('Traiettoria di stato del pendolo (evoluzione libera)')

xlabel('tempo [s]')
ylabel('stato')
legend('Posizione angolare', 'Velocità angolare')
grid on; zoom on; box on;

% evoluzione forzata
figure
plot(time_forced,traj_forced)
title('Traiettoria di stato del pendolo (evoluzione forzata)')

xlabel('tempo [s]')
ylabel('stato')
legend('Posizione angolare', 'Velocità angolare')
grid on; zoom on; box on;

% confronto evoluzione "completa" con libera + forzata
figure
plot(time,traj)

grid on; zoom on; box on;

hold on;

plot(time,traj_free + traj_forced)

xlabel('tempo [s]')
ylabel('stato')
title('Traiettoria di stato del pendolo')

grid on; zoom on; box on;

legend('Posizione angolare "completa"', 'Velocità angolare "completa"','Posizione angolare libera + forzata', 'Velocità angolare libera + forzata')


