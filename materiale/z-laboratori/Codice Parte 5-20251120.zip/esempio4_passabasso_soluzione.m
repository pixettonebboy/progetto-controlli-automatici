%
% Azione filtrante dei sistemi dinamici
%
close all; clear all; clc;

% Sistema: filtro PASSA-BASSO con pulsazione di taglio a 10 rad/s
mu = 1;    % guadagno
T  = 0.05; % costante di tempo

% parametri della sinusoide in ingresso
A_n = 1;
omega = 2;      % pulsazione: 2 rad/s


tt = 0:1e-4:10; % intervallo temporale: da 0 ad 10 con passo 0.01

% parametri del rumore
enable_noise = 1;
omega_noise = 10000;


%% simulazione

fprintf('Pulsazione segnale in ingresso: %.2f rad/s\n', omega);
fprintf('Pulsazione di taglio: %.2f rad/\n', 1/T);

% definizione del sistema
s = tf('s');
G = mu/(1+T*s);

% definizione dell'ingresso
uu = sin(omega*tt);

if enable_noise
    uu = uu + A_n*sin(omega_noise*tt);
end

% simulazione sistema
yy = lsim(G, uu, tt);

%% plot

% diagramma di bode
figure;
bode(G);
box on; zoom on; grid on;

% plot ingresso-uscita
figure;
hold on; box on; zoom on; grid on;
plot(tt,uu,'LineWidth',1,'DisplayName','u(t)');
plot(tt,yy,'LineWidth',1,'DisplayName','y(t)');
ylim([-2.3,2.3]);
xlabel('t');
legend;
