close all; clear all; clc;

mu = 10;

xi = 0.5;

omega_n = 5;

tau_1 = 0.001;
tau_2 = 0.005;

T_1 = 0.01;
T_2 = 0.002;
T_3 = 0.0001;

s = tf('s');

F = mu*omega_n^2/(s^2 + 2*xi*omega_n*s + omega_n^2)*(1+tau_1*s)*(1+tau_2*s)/((1+T_1*s)*(1+T_2*s)*(1+T_3*s));

F_tilde = mu*omega_n^2/(s^2 + 2*xi*omega_n*s + omega_n^2);

bode(F);

hold on; grid on; zoom on;

bode(F_tilde);

legend('F(s)','\tilde{F}(s)','Interpreter', 'latex');

figure

step(F);

hold on; grid on;

step(F_tilde);

legend('y(t)','\tilde{y}(t)','Interpreter', 'latex');