clear all; close all; clc;

% ciclo su valori di mu
for mu=[0.1, 1, 10, 100, 1000]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    hold on; box on; zoom on; grid on;

   
end

legend('\mu = 0.1', '\mu = 1','\mu = 10','\mu = 100','\mu = 1000','Intepreter', 'Latex')

% ciclo su valori di tau
for tau=[0.1, 1, 10, 100, 1000]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;

   
end

legend('\tau = 0.1', '\tau = 1','\tau = 10','\tau = 100','\tau = 1000','Intepreter', 'Latex')



% ciclo su valori di tau
for tau=[-0.1, -1, -10, -100, -1000]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;

   
end

legend('\tau = -0.1', '\tau = -1','\tau = -10','\tau = -100','\tau = -1000','Intepreter', 'Latex')

% ciclo su valori di tau
for T=[0.1, 1, 10, 100, 1000]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('T = 0.1', 'T = 1','T = 10','T = 100','T = 1000','Intepreter', 'Latex')