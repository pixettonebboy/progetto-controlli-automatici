%
% Azione filtrante dei sistemi dinamici: esempio onda quadra
%
close all; clear all; clc;

% Sistema: filtro PASSA-BASSO con pulsazione di taglio in a 10 rad/s
mu = 1;   % guadagno
T  = 0.05; % costante di tempo

% parametri della sinusoide in ingresso
A_n   = 1;
omega = 2;      % pulsazione: 2 rad/s

tt = 0:1e-4:10; % intervallo temporale: da 0 ad 10 con passo 0.01

% variabile flag per considerare presenza disturbo
enable_noise = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parametri segnale disturbo
U_d = 100;
omega_d = 1e4;


%% simulazione


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Stampare pulsazione nominale d'ingresso e pulsazione di taglio del sistema %%%
%fprintf('Pulsazione segnale in ingresso: %.2f rad/s\n', ...);                 %%%
%fprintf('Pulsazione di taglio: %.2f rad/\n', ...);                            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%
%%% definire FdT %%%
%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Definire segnale d'ingresso %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if enable_noise
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Aggiungere il disturbo all'ingresso nominale %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare risposta del sistema %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% plot

% diagramma di bode
figure;
bode(G);
box on; zoom on; grid on;

% plot ingresso-uscita
figure;
hold on; box on; zoom on; grid on;
plot(tt,uu,'LineWidth',1,'DisplayName','u(t)');
plot(tt,yy,'LineWidth',1,'DisplayName','y(t)');
ylim([-2.3,2.3]);
xlabel('t');
legend;
