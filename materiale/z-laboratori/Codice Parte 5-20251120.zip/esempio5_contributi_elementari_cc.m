clear all; close all; clc;

% ciclo su valori di zeta
for zeta=[0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\zeta = 0.1', '\zeta = 0.4','\zeta = 0.7','\zeta = 1','Intepreter', 'Latex')

% ciclo su valori di zeta
for zeta=-[0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\zeta = -0.1', '\zeta = -0.4','\zeta = -0.7','\zeta = -1','Intepreter', 'Latex')


% ciclo su valori di xi
for xi = [0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\xi = 0.1', '\xi = 0.4','\xi = 0.7','\xi = 1','Intepreter', 'Latex')

% ciclo su valori di xi
for xi = -[0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\xi = -0.1', '\xi = -0.4','\xi = -0.7','\xi = -1','Intepreter', 'Latex')