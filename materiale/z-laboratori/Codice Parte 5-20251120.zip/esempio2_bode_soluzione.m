close all; clear all; clc;

% parametri FdT
mu  = 100;
T   = 10;
tau = 100;


s = tf('s');

G_1 = tf(mu);
G_2 = 1/(1+T*s);
G_3 = 1+tau*s;

G = G_1*G_2*G_3;

figure

bode(G_1);


figure 

bode(G_2)

figure

bode(G_3)

figure

bode(G)