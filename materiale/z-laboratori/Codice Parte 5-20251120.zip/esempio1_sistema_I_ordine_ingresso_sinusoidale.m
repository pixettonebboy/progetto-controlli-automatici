%
% Sistema del primo ordine: risposta ad ingresso sinusoidale
%
close all; clear all; clc;

% parametri del sistema
mu = 0.75; % guadagno
T  = 0.01; % costante di tempo

% parametri della sinusoide in ingresso
omega = 1e2;     % pulsazione: 100 rad/s

%%%%%%%%%%%%%%%%%%%%
%%% Definire FdT %%%
%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare guadagno (sia in Decibel sia lineare) e sfasamento della G nella pulsazione d'ingresso %%%
%fprintf('Guadagno: %.2f dB (cioè fattore moltiplicativo: %.2f)\n', ...,...);                        %%%
%fprintf('Sfasamento: %.2f gradi\n', ...);                                                           %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tt = 0:1e-3:10; % intervallo temporale: da 0 ad 0.3 con passo 0.001


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Definire segnale di ingresso %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare segnale di uscita %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% plot

% plot ingresso-uscita
figure;
hold on; box on; zoom on; grid on;
plot(tt,uu,'LineWidth',1,'DisplayName','u(t)');
plot(tt,yy,'LineWidth',1,'DisplayName','y(t)');
xlabel('t');
legend;
