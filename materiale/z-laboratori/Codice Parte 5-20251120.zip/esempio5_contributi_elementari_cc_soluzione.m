clear all; close all; clc;

alpha_n = 10;

s = tf('s');

% ciclo su valori di zeta
for zeta=[0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    G = 1 + 2*s*zeta/alpha_n + s^2/(alpha_n^2);
    %%% ottenere diagramma di Bode %%%
    bode(G);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\zeta = 0.1', '\zeta = 0.4','\zeta = 0.7','\zeta = 1','Intepreter', 'Latex')

figure 


% ciclo su valori di zeta
for zeta=-[0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    G = 1 + 2*s*zeta/alpha_n + s^2/(alpha_n^2);
    %%% ottenere diagramma di Bode %%%
    bode(G);
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\zeta = -0.1', '\zeta = -0.4','\zeta = -0.7','\zeta = -1','Intepreter', 'Latex')

figure

omega_n = 10;

% ciclo su valori di xi
for xi = [0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    G = 1/(1 + 2*s*xi/omega_n + s^2/(omega_n^2));
    %%% ottenere diagramma di Bode %%%
    bode(G);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\xi = 0.1', '\xi = 0.4','\xi = 0.7','\xi = 1','Intepreter', 'Latex')

figure 

% ciclo su valori di xi
for xi = -[0.1, 0.4, 0.7, 1]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% definire Fdt               %%%
    %%% definire Fdt               %%%
    G = 1/(1 + 2*s*xi/omega_n + s^2/(omega_n^2));
    %%% ottenere diagramma di Bode %%%
    bode(G);
    %%% ottenere diagramma di Bode %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    hold on; box on; zoom on; grid on;
   
end

legend('\xi = -0.1', '\xi = -0.4','\xi = -0.7','\xi = -1','Intepreter', 'Latex')