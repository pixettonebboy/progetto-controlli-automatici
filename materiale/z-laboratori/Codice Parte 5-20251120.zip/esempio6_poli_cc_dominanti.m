close all; clear all; clc;

%%% inserire parametri L
mu = 10;
xi = 0.5;
omega_n = 5;
tau_1 = 0.001;
tau_2 = 0.005;
T_1 = 0.01;
T_2 = 0.002;
T_3 = 0.0001;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% dichiarare F e F_tilde %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Confrontare diagrammi di Bode di F e F_tilde %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legend('F(s)','\tilde{F}(s)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Mostrare risposta a gradino di F e F_tilde %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legend('y(t)','\tilde{y}(t)');