close all; clear all; clc;

% parametri fisici del sistema
mm = 0.5;   % kg
ll = 0.6; % metri
gg = 9.81;  % m/s^2
bb = 0.25;  % coefficiente d'attrito (b)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Definire condizioni iniziali %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% intervallo di tempo
interv = 0:0.1:30; % da 0 a 30 secondi

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Definire coppia di equilibrio x_e u_e %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Definire matrici  A, B del sistema linearizzato intorno al punto di equilibrio %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Progettare matrice K (scegliendo a piacere gli autovalori di A+BK) %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Dichiarare funzione anonima per il controllore e includerla in dyn (vedi sotto) %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%dyn = @(t,x) [x(2);-gg/ll*sin(x(1))-bb*x(2)/(mm*ll^2)+.../(mm*ll^2)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Simulare pendolo controllato (N.B.: la parte grafica usa traj) %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Animation

xx=traj';
pivotPoint = [2,2];
radius = .1; %of the bob

position = pivotPoint - (ll*...
                     [-sin(xx(1,1)) cos(xx(1,1))]);
 
rectHandle = rectangle('Position',[(position - radius/2) radius radius],...
                          'Curvature',[1,1],'FaceColor','r'); %Pendulum bob

lineHandle = line([pivotPoint(1) position(1)],...
    [pivotPoint(2) position(2)], 'LineWidth',2); %pendulum rod
axis equal
%Run simulation, all calculations are performed in cylindrical coordinates
for tt=1:length(interv)
    
    grid on
 
    position = pivotPoint - (ll*...
                     [-sin(xx(1,tt)) cos(xx(1,tt))]);
 
    %Update figure with new position info
    set(rectHandle,'Position',[(position - radius/2) radius radius]);
    set(lineHandle,'XData',[pivotPoint(1) position(1)],'YData',...
        [pivotPoint(2) position(2)]);
    axesHandle = gca;
xlim(axesHandle, [(pivotPoint(1) - ll - radius ) ...
                            (pivotPoint(1) + ll + radius )] );
ylim(axesHandle, [(pivotPoint(2) - ll - radius) ...
                            (pivotPoint(2) +ll + radius)] );
 drawnow; %Forces MATLAB to render the pendulum
 if tt==1
     pause(0.5)
 else
    pause(0.05) 
 end
end
