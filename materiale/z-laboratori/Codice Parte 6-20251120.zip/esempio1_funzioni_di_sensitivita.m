close all; clear all; clc;

%%%% parametri FdT
mu  = 50;
tau = 10;
T_1 = 50;
T_2 = 1000;


%%%%%%%%%%%%%%%%%%%%%%
%%% Dichiarare FdT %%%
%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% calcolare e stampare pulsazione critica omega_c %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Confrontare diagramma di Bode di L ed F %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legend('L(j\omega)','F(j\omega)')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Confrontare diagramma di Bode di 1/L ed S %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

legend('1/L(j\omega)','S(j\omega)');