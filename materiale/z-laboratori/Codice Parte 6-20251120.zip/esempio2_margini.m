% Esempi margini ampiezza e fase
% 
% Controlli Automatici T
% 2024/25
%
%

clear all, close all, clc

%%% parametri FdT
mu = 100;
T_1 = 1;
T_2 = 0.01;
T_3 = 0.001;

%%%%%%%%%%%%%%%%%%%%%%
%%% Dichiarare FdT %%%
%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare margini %%%
%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% stampare info margini %%%
%fprintf('La FdT L ha margine di ampiezza %.1f (%.1f dB)  (in corrispondenza di %.1f rad/s).\n',...);
%fprintf('La FdT L ha margine di fase %.1f gradi (in corrispondenza di %.1f rad/s).\n',...);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Visualizzare margini su Diagramma di Bode %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Mostrare risposta a gradino del sistema retroazionato %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% definire le FdT LL_1 LL_2 LL_3 LL_4 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% mostrare (separatamente) le risposte a gradino retroazionando LL_1 LL_2 LL_3 LL_4 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


