close all; clear all; clc;

mu = 50;


tau = 100;
T_1 = 50;
T_2 = 1000;


s = tf('s');

L = mu*(1+tau*s)/((1+T_1*s)*(1+T_2*s));

[M_a,M_f,omega_pi,omega_c] = margin(L);

fprintf('La pulsazione critica di L è %.1f rad/s.\n',omega_c);

F = L/(1+L);

S = 1/(1+L);

bode(L);

hold on; grid on; zoom on;

bode(F);

legend('L(j\omega)','F(j\omega)');

figure
bode(1/L);

hold on; grid on; zoom on;

bode(S);

legend('1/L(j\omega)','S(j\omega)');