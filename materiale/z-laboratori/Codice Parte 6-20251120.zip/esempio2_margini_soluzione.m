% Esempi margini ampiezza e fase
% 
% Controlli Automatici T
% 2024/25
%
%

clear all, close all, clc

s = tf('s');


mu = 1e2;
TT1 = 1;
TT2 = 1e-2;
TT3 = 1e-3;

LL = mu/(1 + TT1*s)/(1 + TT2*s)/(1 + TT3*s);

[M_a,M_f,omega_pi,omega_c] = margin(LL);

M_a_db = 20*log10(M_a);

fprintf('La FdT L ha margine di ampiezza %.1f (%.1f dB)  (in corrispondenza di %.1f rad/s).\n',M_a,M_a_db,omega_pi);
fprintf('La FdT L ha margine di fase %.1f gradi (in corrispondenza di %.1f rad/s).\n',M_f,omega_c);

figure 
margin(LL);

figure 
step(LL/(1+LL));

legend('Risposta di L(s)')

tilde_LL_1 = 0.99*M_a*LL;

figure 

step(tilde_LL_1/(1+tilde_LL_1));

legend('Risposta di L_1(s)')

tilde_LL_2 = 1.01*M_a*LL;

figure 

step(tilde_LL_2/(1+tilde_LL_2));

legend('Risposta di L_2(s)')

tilde_LL_3 = exp(-s*deg2rad(M_f)/omega_c*0.99)*LL;

figure 

step(tilde_LL_3/(1+tilde_LL_3));

legend('Risposta di L_3(s)')

tilde_LL_4 = exp(-s*deg2rad(M_f)/omega_c*1.01)*LL;

figure 

step(tilde_LL_4/(1+tilde_LL_4));

legend('Risposta di L_4(s)')

