%
% Esempio 4: Pendolo
%
close all; clear all; clc;

% parametri fisici del sistema
mass = 0.5;   % kg
length = 0.6; % metri
grav = 9.81;  % m/s^2
attr = 0.25;  % coefficiente d'attrito (b)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Inserire condizione iniziale del pendolo %%%
theta_0 = deg2rad(30);
theta_punto_0 = 0;

x_0 =[theta_0;theta_punto_0];
%%% Definire funzione che modelli l'input    %%%

inp = @(t) 2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% intervallo di tempo
interv = [0 10]; % da 0 a 10 secondi

%% risoluzione equazione differenziale

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Definire funzione che modelli la dinamica del pendolo (n.b.: usare anche l'input) %%%
f_tilde = @(t,x) [x(2);-grav/length*sin(x(1)) - attr*x(2)/(mass*length^2) + inp(t)/(mass*length^2)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calcolare la traiettoria del pendolo nell'intervallo interv  %%%
[time,traj] = ode45(f_tilde,interv,x_0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% plot

figure
plot(time,traj)
title('Traiettoria di stato del pendolo')
xlim(interv)
xlabel('tempo [s]')
ylabel('stato')
legend('Posizione angolare', 'Velocità angolare')
grid on; zoom on; box on;
