function [prod_scal] = prodottoScalare(v1,v2)
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here
arguments (Input)
    v1
    v2
end

arguments (Output)
    prod_scal
end

len = length(v1);

prod_scal = 0;
for ii=1:len
    prod_scal = prod_scal + v1(ii)*v2(ii);
end

end