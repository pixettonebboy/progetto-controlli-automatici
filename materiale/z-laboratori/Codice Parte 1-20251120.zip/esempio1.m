clc
clear
close all

t = 2;
y = 3;

v = [t, y];

str = 'la norma di v e`:';

fprintf('%s %.1f\n',str,norm(v));

fprintf('Vettore v %d\n',v);

str2 = 'CAT25-26';

fprintf('\t%s',str2);