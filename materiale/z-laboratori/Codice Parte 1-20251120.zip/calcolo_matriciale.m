%
% Esempio 1: prodotto matriciale con il ciclo for
%
n = 3;
m = 4;
p = 2;


A = rand(n,m)
B = rand(m,p)

A*B

C = [];

for i=1:n
  for j=1:p
    C(i,j) = 0;
    for k=1:m
      C(i,j) = C(i,j) + A(i,k)*B(k,j);
    end
  end
end
    
C

%%
for i=1:n
  for j=1:p
    C(i,j) = A(i,:)*B(:,j);
  end
end
    
C
