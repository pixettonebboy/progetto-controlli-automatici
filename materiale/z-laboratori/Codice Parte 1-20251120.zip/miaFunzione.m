function [somma,massimo] = miaFunzione(a,b)
%la funzione calcola la somma ed il massimo di due numeri di input
arguments (Input)
    a(1,1)
    b(1,1)
end

arguments (Output)
    somma
    massimo
end

somma = a+b;
massimo = max(a,b);
end