%
% Esempio 4: Segnali di base
%
close all; clear all; clc;

% parametri
a = 5;
f = 0.5;
phi = 0.2;

% valori su asse orizzontale
t = 0:0.01:10;

%% Figura 1

y = exp(-2*t);

figure
plot(t,y)
title('Figura 1')
xlim([0,10])
xlabel('t')
ylabel('y')

%% Figura 2

y = a*sin(2*pi*f*t + phi);

figure
plot(t,y)
title('Figura 2')
xlim([0,10])
xlabel('t')
ylabel('y')

%% Figura 3

y = a * t .* sin(2*pi*f*t + phi);

figure
plot(t,y)
title('Figura 3')
xlim([0,10])
xlabel('t')
ylabel('y')

%% Figura 4

y = a * t.^2 .* sin(2*pi*f*t + phi) .* exp(-2*t);

figure
plot(t,y)
title('Figura 4')
xlim([0,10])
xlabel('t')
ylabel('y')
